global using Inventory.Shared;
